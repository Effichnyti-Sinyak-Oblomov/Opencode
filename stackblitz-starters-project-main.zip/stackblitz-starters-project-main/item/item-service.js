import SqliteLinker from '../db/sqlite.js';
import ItemEntity from './item-entity.js';

const SELECT_ITEM = `
  select * from item
  where id = ?
    and coalesce(is_deleted, 0) = 0
`;

export default class ItemService {
  constructor(linker = new SqliteLinker()) {
    this.link = linker;
  }

  async getAll({ ids } = {}) {
    const itemIds = ItemService.normalizeIds(ids);

    if (itemIds.length === 0) {
      const rows = await this.link.all(`
        select * from item
        where coalesce(is_deleted, 0) = 0
        order by id
      `);

      return rows.map(ItemEntity.fromRow);
    }

    const rows = await this.link.all(
      `
        select * from item
        where coalesce(is_deleted, 0) = 0
          and id in (${this.link.createPlaceHolders(itemIds)})
        order by id
      `,
      itemIds
    );

    return rows.map(ItemEntity.fromRow);
  }

  async getOne(id) {
    const row = await this.link.get(SELECT_ITEM, [id]);
    return ItemEntity.fromRow(row);
  }

  async softDelete(id) {
    const { changes } = await this.link.run(
      `
        update item
        set is_deleted = 1
        where id = ?
          and coalesce(is_deleted, 0) = 0
      `,
      [id]
    );

    return changes > 0;
  }

  async update(
    id,
    { name, properties, status, location_id, current_location_id, category_id }
  ) {
    const { block, values } = this.link.createSetBlock({
      name,
      properties:
        properties === undefined
          ? undefined
          : ItemEntity.serializeProperties(properties),
      status,
      location_id,
      current_location_id,
      category_id,
    });

    if (block.length === 0) return this.getOne(id);

    const { changes } = await this.link.run(
      `
        update item
        set ${block}
        where id = ?
          and coalesce(is_deleted, 0) = 0
      `,
      [...values, id]
    );

    if (changes === 0) return null;

    return this.getOne(id);
  }

  async create({
    name,
    properties,
    status,
    location_id,
    current_location_id,
    category_id,
  }) {
    const values = [
      name,
      ItemEntity.serializeProperties(properties),
      status,
      location_id,
      current_location_id,
      category_id,
    ];

    const { lastId } = await this.link.run(
      `
        insert into item
          (name, properties, status, location_id, current_location_id, category_id)
        values (${this.link.createPlaceHolders(values)})
      `,
      values
    );

    return this.getOne(lastId);
  }

  static normalizeIds(ids) {
    if (ids === undefined || ids === null || ids === '') return [];

    const raw = Array.isArray(ids) ? ids : String(ids).split(/[,\s]+/);

    return [
      ...new Set(
        raw
          .map((value) => Number(value))
          .filter((value) => Number.isInteger(value) && value > 0)
      ),
    ];
  }
}
