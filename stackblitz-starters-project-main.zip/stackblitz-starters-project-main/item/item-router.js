import Router from '@koa/router';
import ItemController from './item-controller.js';

/**
 * Создаёт роутер /items с внедрённым сервисом.
 * Внедрение сервиса нужно для тестов (своя БД) и для запуска приложения.
 */
export function createItemRouter(service) {
  const router = new Router({
    prefix: '/items',
  });

  const controller = new ItemController(service);

  router.get('/', controller.getItems.bind(controller));
  router.get('/:id', controller.getItem.bind(controller));
  router.patch('/:id', controller.updateItem.bind(controller));
  router.post('/', controller.createItem.bind(controller));
  router.delete('/:id', controller.deleteItem.bind(controller));

  return router;
}
