export function isString(data) {
  return typeof data === 'string';
}

export function isNumber(data) {
  return typeof data === 'number';
}

export function isEmpty(data) {
  if (data === undefined || data === null || data === '') return true;
  if (Array.isArray(data)) return data.length === 0;
  if (typeof data === 'object') return Object.keys(data).length === 0;
  return false;
}

export function isNotEmpty(data) {
  return !isEmpty(data);
  //return (data !== undefined || data !== null || JSON.stringify(data) !== '{}' || data !== '');
}

export function isNotEmptyArray(data) {
  return Array.isArray(data) && data.length !== 0;
}

export function isCorrectStatus(enums, status) {
  return Object.values(enums).includes(status);
}
