/**
 * Начальная схема БД.
 * Миграция экспортирует up(linker) и не открывает соединение самостоятельно —
 * этим управляет db/migration.js.
 */
export async function up(linker) {
  // create Category table
  await linker.run(`
    create table if not exists category (
      id integer primary key autoincrement,
      name text not null,
      parent_id integer,
      foreign key (parent_id) references category(id)
        on delete set null
    )
  `);

  // create Structure table
  await linker.run(`
    create table if not exists structure (
      id integer primary key autoincrement,
      name text not null,
      address text
    )
  `);

  // create Floor table
  await linker.run(`
    create table if not exists floor (
      id integer primary key autoincrement,
      name text not null,
      structure_id integer,
      foreign key (structure_id) references structure(id)
        on delete set null
    )
  `);

  // create Room table
  await linker.run(`
    create table if not exists room (
      id integer primary key autoincrement,
      name text not null,
      floor_id integer,
      foreign key (floor_id) references floor(id)
        on delete set null
    )
  `);

  // create Place table
  await linker.run(`
    create table if not exists place (
      id integer primary key autoincrement,
      name text not null,
      room_id integer,
      foreign key (room_id) references room(id)
        on delete set null
    )
  `);

  // create Location table
  await linker.run(`
    create table if not exists location (
      id integer primary key autoincrement,
      name text not null,
      place_id integer,
      foreign key (place_id) references place(id)
        on delete set null
    )
  `);

  // create Item table
  await linker.run(`
    create table if not exists item (
      id integer primary key autoincrement,
      is_deleted integer not null default 0,
      name text not null,
      properties text not null,
      status text not null,
      location_id integer not null,
      current_location_id integer not null,
      category_id integer not null,
      foreign key (location_id) references location(id)
        on delete cascade,
      foreign key (current_location_id) references location(id)
        on delete cascade,
      foreign key (category_id) references category(id)
        on delete cascade
    )
  `);

  await linker.run(
    'create index if not exists item_location_id_idx on item(location_id)'
  );
  await linker.run(
    'create index if not exists item_current_location_id_idx on item(current_location_id)'
  );
  await linker.run(
    'create index if not exists item_category_id_idx on item(category_id)'
  );
}
