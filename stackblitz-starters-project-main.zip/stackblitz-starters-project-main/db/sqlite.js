import sqlite3 from 'sqlite3';

/**
 * Небольшая обёртка над sqlite3, которая приводит callback API к Promise API.
 * Все запросы выполняются через параметры (?), что защищает от SQL-инъекций.
 */
export default class SqliteLinker {
  constructor(filename = process.env.DB_FILE || './database.db') {
    this.filename = filename;
    this.db = null;
  }

  // Подключается к базе данных и включает проверку внешних ключей
  async connect() {
    if (this.db) return this.db;

    this.db = await new Promise((resolve, reject) => {
      const db = new sqlite3.Database(this.filename, (err) => {
        if (err) {
          reject(err);
          return;
        }

        resolve(db);
      });
    });

    await this.run('PRAGMA foreign_keys = ON');

    return this.db;
  }

  /**
   * Выполняет SQL-запрос, который не возвращает строк (INSERT, UPDATE, DELETE, CREATE).
   * Возвращает { lastId, changes }.
   */
  async run(sql, params = []) {
    const db = await this.#getDb();

    return new Promise((resolve, reject) => {
      db.run(sql, params, function (err) {
        if (err) {
          reject(err);
          return;
        }

        resolve({
          lastId: this.lastID,
          changes: this.changes,
        });
      });
    });
  }

  /**
   * Выполняет SELECT и возвращает одну строку или undefined.
   */
  async get(sql, params = []) {
    const db = await this.#getDb();

    return new Promise((resolve, reject) => {
      db.get(sql, params, (err, row) => {
        if (err) {
          reject(err);
          return;
        }

        resolve(row);
      });
    });
  }

  /**
   * Выполняет SELECT и возвращает массив строк (пустой массив, если ничего не найдено).
   */
  async all(sql, params = []) {
    const db = await this.#getDb();

    return new Promise((resolve, reject) => {
      db.all(sql, params, (err, rows) => {
        if (err) {
          reject(err);
          return;
        }

        resolve(rows);
      });
    });
  }

  // Разрывает соединение с базой данных
  async close() {
    if (!this.db) return;

    const db = this.db;
    this.db = null;

    await new Promise((resolve, reject) => {
      db.close((err) => {
        if (err) {
          reject(err);
          return;
        }

        resolve();
      });
    });
  }

  createPlaceHolders(arr) {
    return Array.from(arr)
      .map(() => '?')
      .join(', ');
  }

  /**
   * Создаёт SET-блок для UPDATE: "name = ?, status = ?".
   * Пропускаются только отсутствующие значения (undefined). Явно переданные
   * null, '' или {} применяются, поэтому поле можно очистить.
   */
  createSetBlock(properties) {
    const values = [];

    const block = Object.entries(properties)
      .map(([key, value]) => {
        if (value === undefined) return null;

        values.push(value);
        return `${key} = ?`;
      })
      .filter((part) => part !== null)
      .join(', ');

    return { block, values };
  }

  async #getDb() {
    if (!this.db) {
      await this.connect();
    }

    return this.db;
  }
}
