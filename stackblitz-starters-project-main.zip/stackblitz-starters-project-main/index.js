import path from 'node:path';
import { pathToFileURL } from 'node:url';
import Koa from 'koa';
import bodyParser from 'koa-bodyparser';
import SqliteLinker from './db/sqlite.js';
import { runMigrations } from './db/migration.js';
import { createItemRouter } from './item/item-router.js';
import ItemService from './item/item-service.js';

export const DEFAULT_DB_FILE =
  process.env.DB_FILE || path.resolve('database.db');

/**
 * Создаёт Koa-приложение: подключает БД, применяет миграции и регистрирует роуты.
 * Возвращает приложение и соединение с БД, чтобы вызывающий код мог его закрыть.
 */
export async function createApp({
  dbFile = DEFAULT_DB_FILE,
  linker = new SqliteLinker(dbFile),
} = {}) {
  await linker.connect();
  await runMigrations(linker);

  const app = new Koa();

  app.use(async (ctx, next) => {
    try {
      await next();
    } catch (err) {
      const status = err.status ?? err.statusCode ?? 500;
      ctx.status = status;
      ctx.body = {
        status,
        message:
          status < 500
            ? err.message || 'Ошибка запроса'
            : 'Внутренняя ошибка сервера',
      };

      if (status >= 500) {
        console.error(err);
      }
    }
  });

  app.use(bodyParser());

  app.use(async (ctx, next) => {
    if (ctx.method === 'GET' && ctx.path === '/') {
      ctx.status = 200;
      ctx.body = {
        status: 'ok',
        endpoints: {
          health: '/health',
          items: '/items',
          itemById: '/items/:id',
        },
      };
      return;
    }

    if (ctx.method === 'GET' && ctx.path === '/health') {
      ctx.status = 200;
      ctx.body = { status: 'ok' };
      return;
    }

    await next();
  });

  const router = createItemRouter(new ItemService(linker));
  app.use(router.routes());
  app.use(router.allowedMethods());

  // Понятный JSON-ответ вместо стандартного текстового "Not Found"
  app.use(async (ctx) => {
    ctx.status = 404;
    ctx.body = {
      status: 404,
      message: `Маршрут ${ctx.method} ${ctx.path} не найден`,
      endpoints: {
        health: '/health',
        items: '/items',
        itemById: '/items/:id',
      },
    };
  });

  return { app, linker };
}

const isMain =
  process.argv[1] &&
  pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;

if (isMain) {
  const port = Number(process.env.PORT) || 3000;
  const { app, linker } = await createApp();

  const server = app.listen(port, () => {
    console.log(`Server is started on http://localhost:${port}`);
  });

  const shutdown = () => {
    server.close(async () => {
      await linker.close();
      process.exit(0);
    });
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}
