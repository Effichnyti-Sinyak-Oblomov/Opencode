# AGENTS.md

Гид по проекту для AI-агентов и разработчиков. Описывает архитектуру, соглашения и подводные камни.

## Обзор проекта

REST API на **Koa 3** для учёта предметов (item) с хранением в **SQLite** (`sqlite3`).
Чистый JavaScript, **ESM** (`"type": "module"`), без TypeScript и сборки. Требуется **Node.js >= 20**.
Тесты используют встроенный раннер `node --test` (без Jest/Mocha).

## Команды

```bash
npm start          # node index.js — запуск сервера
npm run dev        # node --watch index.js — запуск с автоперезагрузкой
npm run migrate    # node db/migrate-cli.js — применить миграции вручную
npm test           # node --test — все тесты из test/
```

Линтера, форматтера и typecheck в проекте **нет** (`.vscode/settings.json` — только закомментированные шаблоны).
Единственная проверка — `npm test`. После изменений обязательно запускать тесты.

## Переменные окружения

- `DB_FILE` — путь к файлу БД (по умолчанию `database.db` в текущей директории).
- `PORT` — порт сервера (по умолчанию `3000`).

`.env` не используется и не подключён; `.gitignore` игнорирует `*.db`, `database.db`, `*.db-shm`, `*.db-wal`, `.env`, `node_modules`.

## Структура каталогов

```
index.js                 # createApp(): подключение БД, миграции, middleware, роуты, 404, graceful shutdown
utils.js                 # isString, isNumber, isEmpty, isNotEmpty, isNotEmptyArray, isCorrectStatus
db/
  sqlite.js              # SqliteLinker — Promise-обёртка над callback API sqlite3
  migration.js           # runMigrations(linker, directory)
  migrate-cli.js         # CLI-запуск миграций
  enums.js               # EItemStatus
  migrations/            # файлы миграций, экспортируют up(linker)
  dtos/                  # structure_dto.js, floor_dto.js (в API item не используются)
item/
  item-entity.js         # ItemEntity: преобразование строки БД <-> API-вид
  item-service.js        # ItemService: SQL-запросы
  item-controller.js     # ItemController: валидация, HTTP-статусы, ответы
  item-router.js         # createItemRouter(service): маршруты /items
test/
  units.test.js          # unit-тесты утилит, linker, entity, DTO, service
  item-api.test.js       # интеграционные тесты через реальный HTTP (fetch) и временную БД
```

## Архитектура и поток запроса

Слои разделены по файлам, каждый ресурс живёт в своей папке (`item/`):

```
HTTP -> router (@koa/router) -> controller -> service -> SqliteLinker -> SQLite
                                     |
                                ItemEntity (маппинг строк)
```

- **router** — только привязка URL+метода к методам контроллера (`bind(controller)`), без логики.
- **controller** — разбор/валидация входа, выбор HTTP-статуса, формирование тела ответа. Кидает `err` дальше в централизованный обработчик ошибок.
- **service** — SQL и доменные операции. Не знает про HTTP.
- **entity** — приведение строки БД к API-виду (JSON `properties`, boolean `is_deleted`).
- **DTO** (`db/dtos/`) — валидаторы отдельных сущностей (`StructureDto`, `FloorDto`), пока не подключены к API; не удалять без причины.

Внедрение зависимостей через конструктор (`new ItemService(linker)`, `createItemRouter(service)`) — нужно для тестов со своей БД.

## API

Базовые служебные маршруты (`index.js`):

- `GET /` → `{ status: 'ok', endpoints: {...} }`
- `GET /health` → `{ status: 'ok' }`
- Любой неизвестный маршрут → JSON `404 { status, message, endpoints }`.

Маршруты `/items` (`item-router.js`):

| Метод | Путь | Назначение |
|---|---|---|
| GET | `/items?ids=1,2` | список активных item; `ids` — необязательный фильтр |
| GET | `/items/:id` | один item |
| POST | `/items` | создание, ответ `201` |
| PATCH | `/items/:id` | частичное обновление |
| DELETE | `/items/:id` | **мягкое** удаление (`is_deleted = 1`), ответ `200 {status,message}` |

Форматы ответов:

- Успех: `{ data: <item|item[]> }` (кроме DELETE — `{ status: 200, message: 'OK' }`).
- Ошибка: `{ status: <код>, message: '<текст на русском>' }`.
- 500 маскируется общим сообщением `Внутренняя ошибка сервера`, реальная ошибка пишется в `console.error`.

`ids` (`ItemService.normalizeIds`): принимает массив или строку, делит по `,` и пробелам, приводит к `Number`, оставляет только положительные целые, удаляет дубликаты. Пустая строка/`undefined`/`null` → `[]` (без фильтра). Если `ids` задан, но после нормализации пуст → `400`.

## Валидация item (`item-controller.js`)

Поля: `name`, `properties`, `status`, `location_id`, `current_location_id`, `category_id`.

- `name` — непустая строка (обрезается при проверке через `.trim()`).
- `properties` — непустой plain-объект (не `null`, не массив).
- `status` — одно из `EItemStatus` (`db/enums.js`): `on_place`, `broken`, `unlocated`.
- `location_id`, `current_location_id`, `category_id` — положительные целые числа.
- `:id` в пути — положительное целое, иначе `400`.
- Тело должно быть объектом (не массив, не `null`), иначе `400`.
- `PATCH` — частичная валидация только переданных полей; пустой набор полей → `400`.
- Ошибки FK (`SQLITE_CONSTRAINT*` или текст с `constraint`/`foreign key`) маппятся в `400` с сообщением про несуществующую категорию/локацию.

## База данных

### SqliteLinker (`db/sqlite.js`)

- Оборачивает callback API `sqlite3` в Promise: `run` → `{ lastId, changes }`, `get` → строка|`undefined`, `all` → массив.
- Ленивое подключение в `#getDb()`; `connect()` идемпотентен.
- При подключении выполняет `PRAGMA foreign_keys = ON` (каскады/внешние ключи работают только при включённом PRAGMA).
- **Все запросы только с параметрами `?`** — защита от SQL-инъекций. Не подставлять значения в SQL конкатенацией.
- `createPlaceHolders(arr)` → `'?, ?, ?'`.
- `createSetBlock(properties)` → `{ block: 'a = ?, b = ?', values: [...] }`. Пропускается только `undefined` (поле не передано); явные `null`, `''` и `{}` попадают в запрос, поэтому поле можно очистить. Тест: `createSetBlock skips only undefined values`.
- `close()` обнуляет `this.db`.

### Миграции (`db/migration.js`)

- Файлы из `db/migrations/*.js` берутся по `readdir` и **сортируются по дате из имени** `дд-мм-гг.js` (см. `compareMigrations`), поэтому `01-10-26.js` корректно применится после `23-09-26.js`. Файлы без даты в имени идут после датированных и сортируются между собой лексикографически.
- Каждый файл экспортирует `async function up(linker)`; соединение не открывает — его передаёт вызывающий код.
- Применённые миграции фиксируются в таблице `schema_migrations(name)`; повторно не выполняются.
- Каждая миграция выполняется в транзакции (`begin`/`commit`/`rollback`).
- `createApp()` **автоматически применяет миграции при старте**, поэтому обычно `npm run migrate` вручную не нужен. `migrate-cli.js` принимает путь к БД первым аргументом.

### Схема (`db/migrations/23-09-26.js`)

Иерархия локаций:
`category` (самоссылка `parent_id`) и `structure → floor → room → place → location`.
`item` ссылается на `location_id`, `current_location_id`, `category_id`.

- Все `id` — `integer primary key autoincrement`.
- `item.is_deleted` — `integer not null default 0` (soft delete).
- `item.properties` — `text not null` (JSON-строка).
- `item.status` — `text not null` (значения из `EItemStatus`).
- `item` FK: `location_id`, `current_location_id`, `category_id` → `on delete cascade` (нельзя удалить используемую локацию/категорию без каскада).
- `category.parent_id`, `floor.structure_id`, `room.floor_id`, `place.room_id`, `location.place_id` → `on delete set null`.
- Индексы по `item(location_id)`, `item(current_location_id)`, `item(category_id)`.

### ItemEntity (`item/item-entity.js`)

- `fromRow(row)` → `null` для пустой строки; иначе `{ ...row, is_deleted: Boolean(...), properties: parse }`.
- `parseProperties`: строка парсится как JSON, при ошибке возвращается как есть; не-строка → `{}` для `null`/`undefined`.
- `serializeProperties`: строка возвращается как есть, иначе `JSON.stringify`.

### Soft delete

Все чтения фильтруют `coalesce(is_deleted, 0) = 0`. Удалённые item не видны в `GET`/`PATCH`/`DELETE` (повторное удаление → `404`). В `UPDATE` условие `coalesce(is_deleted, 0) = 0` тоже присутствует; при `changes === 0` `update` возвращает `null` → контроллер отдаёт `404`.

## Тесты

- `npm test` (`node --test`) запускает оба файла из `test/`.
- `test/item-api.test.js` поднимает реальное приложение через `createApp({ dbFile })` во временной директории (`mkdtemp` + `tmpdir`), слушает порт `0`, ходит через глобальный `fetch`.
- `beforeEach` очищает таблицы в порядке зависимостей: item → location → place → room → floor → structure → category; затем создаёт фикстуры (`seedFixtures`).
- `after` закрывает сервер, соединение БД и удаляет временную директорию.
- При добавлении тестов сохраняйте стиль: `node:test` + `node:assert/strict`, `describe/test`, отдельные файлы для unit и API.

## Соглашения кода

- ESM: `import`/`export`, `import.meta.url`, никаких `require`.
- 2 пробела, одинарные кавычки, точка с запятой.
- Приватные методы/поля класса — через `#` (`#getBody`, `#validateItemData`).
- JS-идентификаторы — `camelCase`; колонки БД — `snake_case` (не смешивать).
- Сообщения об ошибках API и комментарии/JSDoc — на русском.
- Статические хелперы, не завязанные на экземпляр, — `static` (`ItemService.normalizeIds`, `ItemEntity.fromRow`).
- Не добавлять зависимости без необходимости; стек намеренно минимальный (koa, @koa/router, koa-bodyparser, sqlite3).

## Как добавить новый ресурс (по образцу `item/`)

1. Миграция в `db/migrations/` с более поздней датой в имени (`дд-мм-гг.js`), экспорт `up(linker)`.
2. Папка ресурса: `*-entity.js`, `*-service.js`, `*-controller.js`, `*-router.js` (фабрика `create<X>Router(service)`).
3. Зарегистрировать роутер в `createApp()` (`index.js`) и, при необходимости, добавить endpoint в списки `/` и 404.
4. Валидацию держать в контроллере, SQL — в сервисе, маппинг строк — в entity.
5. Добавить unit- и API-тесты; прогнать `npm test`.

## Подводные камни (кратко)

- `createSetBlock` пропускает только `undefined`; явные `null`/`''`/`{}` применяются (поле можно очистить).
- `isEmpty` считает пустыми `undefined`, `null`, `''`, `{}` и `[]`; `0` — НЕ пустой. Проверка не использует `JSON.stringify`, поэтому безопасна для циклических объектов.
- Внешние ключи работают только благодаря `PRAGMA foreign_keys = ON` в `connect()`.
- `createApp()` сам гоняет миграции — тестовые БД не требуют ручной подготовки.
- `createApp()` возвращает `{ app, linker }`; закрывайте `linker` и сервер (в тестах и shutdown).
- Миграции сортируются по дате из имени файла (`дд-мм-гг.js`); имена без даты — после датированных.
- `properties` в БД — строка; наружу всегда отдаётся распарсенный объект (или исходная строка, если JSON битый).
- Обработчик ошибок отдаёт реальное сообщение для статусов `< 500` и маскирует `500+` общим текстом; детали пишутся в `console.error`.
- `item/index.js` определяет запуск как main через сравнение `pathToFileURL(process.argv[1]).href === import.meta.url` — при рефакторинге не сломать импорт `createApp` в тестах.
